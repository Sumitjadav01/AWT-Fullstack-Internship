
var n1=10,n2="10";


if(n1==n2)
{
    document.write("<br/>n1 and n2 are same.");
}
else
{
    document.write("<br/>n1 and n2 are not same.");
}

/
if(n1===n2){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}