let s1 = "Silver";
let s2 = "oak";
let s3 = "university";
let s4 = s1 + " " + s2+" "+s3
document.write(s4);