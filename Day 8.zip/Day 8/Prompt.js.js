let name=prompt("What is your name");
document.write(name);
var a=parseInt(prompt("Enter your first number:"));
        var b=parseInt(prompt("<br> Enter your last number:"));
        document.write("<br>",a+b);